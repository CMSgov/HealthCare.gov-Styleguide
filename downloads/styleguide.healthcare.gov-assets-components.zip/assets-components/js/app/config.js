// This config is empty, but required since files in common/ may import
// eznode's config.
{}